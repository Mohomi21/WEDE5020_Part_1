# Uzzuri Jewlery

Uzzuri Jewlery is a simple static website showcasing elegant and timeless jewelry collections for both women and men. The site includes information about the brand, a gallery of products, and contact details.

## Project Structure

```
uzzuri_jewlery/
  about.html
  contact.html
  gallery.html
  index.html
  jewlery.html
  _images/
    Uzzuri_logo.jpg
    about.jpg
    background.png
    DrieKo.jpg
    ...
```

## Pages

- **Home** ([index.html](index.html)): Welcome page with an overview of Uzzuri Jewlery.
- **About** ([about.html](about.html)): Information about the brand and its values.
- **Jewlery** ([jewlery.html](jewlery.html)): Showcase of jewelry products.
- **Contact** ([contact.html](contact.html)): Contact information and social media.
- **Gallery** ([gallery.html](gallery.html)): Gallery of jewelry images and a video.

## How to Use

1. Clone or download the repository.
2. Open any HTML file (e.g., `index.html`) in your browser to view the website.
3. All images are stored in the `_images` folder.

